package es.deusto.sd.ecoembes.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.time.LocalDate;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import es.deusto.sd.ecoembes.entity.PlantaReciclaje;

class PlantaServiceTest {

	private PlantaService plantaService;

	@BeforeEach
	void setUp() {
		plantaService = new PlantaService();
		plantaService.addPlanta(new PlantaReciclaje(1, "PlasSB Ltd.", 0.6));
		plantaService.addPlanta(new PlantaReciclaje(2, "ContSocket Ltd.", 0.4));
	}

	@Test
	void capacityOfAPlantWithoutAssignmentsIsItsDailyCapacity() {
		assertEquals(0.6, plantaService.getCapacidadDisponible(1, LocalDate.now()), 0.000001);
		assertEquals(0.4, plantaService.getCapacidadDisponible(2, LocalDate.now().plusDays(10)), 0.000001);
	}

	@Test
	void capacityRejectsUnknownPlantsAndDatesBeyondTenDays() {
		assertThrows(RuntimeException.class, () -> plantaService.getCapacidadDisponible(9, LocalDate.now()));
		assertThrows(IllegalArgumentException.class, () -> plantaService.getCapacidadDisponible(1, LocalDate.now().plusDays(11)));
		assertThrows(IllegalArgumentException.class, () -> plantaService.getCapacidadDisponible(1, null));
	}

	@Test
	void plantsAreReturnedSortedById() {
		assertEquals(2, plantaService.getPlantas().size());
		assertEquals("PlasSB Ltd.", plantaService.getPlantas().get(0).getNombre());
	}
}
