package es.deusto.sd.ecoembes.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import es.deusto.sd.ecoembes.entity.Asignacion;
import es.deusto.sd.ecoembes.entity.EstadoContenedor;
import es.deusto.sd.ecoembes.entity.PersonalEcoembes;
import es.deusto.sd.ecoembes.entity.PlantaReciclaje;

class AsignacionServiceTest {

	private ContenedorService contenedorService;
	private PlantaService plantaService;
	private AsignacionService asignacionService;
	private PersonalEcoembes personal;
	private final LocalDate hoy = LocalDate.now();

	@BeforeEach
	void setUp() {
		contenedorService = new ContenedorService();
		plantaService = new PlantaService();
		asignacionService = new AsignacionService(contenedorService, plantaService);
		personal = new PersonalEcoembes("Ana", "ana@ecoembes.com", "secret");

		// Plant with 0.1 tons per day (= 2000 packagings of 50 grams)
		plantaService.addPlanta(new PlantaReciclaje(1, "PlasSB Ltd.", 0.1));

		contenedorService.crearContenedor(1, "Gran Via 25, Bilbao", "48001", 2000);
		contenedorService.crearContenedor(2, "Calle Ercilla 15, Bilbao", "48009", 2000);
		contenedorService.crearContenedor(3, "Calle Ledesma 8, Bilbao", "48011", 2000);
		contenedorService.crearContenedor(4, "Calle sin datos", "48011", 2000);
		contenedorService.actualizarContenedor(1, hoy, 1000, EstadoContenedor.NARANJA);
		contenedorService.actualizarContenedor(2, hoy, 800, EstadoContenedor.NARANJA);
		contenedorService.actualizarContenedor(3, hoy, 500, EstadoContenedor.VERDE);
	}

	@Test
	void assignmentIsRegisteredWithTheTotalsAndThePerson() {
		Asignacion asignacion = asignacionService.asignarContenedores(personal, 1, hoy, List.of(1L, 2L));

		assertEquals(2, asignacion.getContenedores().size());
		assertEquals(1800, asignacion.getTotalEnvases());
		assertEquals("ana@ecoembes.com", asignacion.getPersonal().getEmail());
		assertEquals(1, asignacionService.getAsignaciones().size());
	}

	@Test
	void assignmentReducesTheAvailableCapacityOfThePlant() {
		double antes = plantaService.getCapacidadDisponible(1, hoy);

		asignacionService.asignarContenedores(personal, 1, hoy, List.of(1L));

		double despues = plantaService.getCapacidadDisponible(1, hoy);
		assertTrue(despues < antes);
		assertEquals(antes - 1000 * Asignacion.PESO_MEDIO_ENVASE_TONELADAS, despues, 0.000001);
	}

	@Test
	void assignmentIsRejectedWhenThePlantHasNoCapacity() {
		// 1000 + 800 + 500 = 2300 packagings > 2000 supported by the plant
		RuntimeException e = assertThrows(RuntimeException.class,
				() -> asignacionService.asignarContenedores(personal, 1, hoy, List.of(1L, 2L, 3L)));

		assertEquals("Insufficient plant capacity", e.getMessage());
		assertTrue(asignacionService.getAsignaciones().isEmpty());
	}

	@Test
	void containerCannotBeAssignedTwiceOnTheSameDate() {
		asignacionService.asignarContenedores(personal, 1, hoy, List.of(1L));

		RuntimeException e = assertThrows(RuntimeException.class,
				() -> asignacionService.asignarContenedores(personal, 1, hoy, List.of(1L)));

		assertEquals("Container already assigned", e.getMessage());
	}

	@Test
	void assignmentRejectsInvalidData() {
		assertThrows(IllegalArgumentException.class, () -> asignacionService.asignarContenedores(personal, 1, hoy, List.of()));
		assertThrows(IllegalArgumentException.class, () -> asignacionService.asignarContenedores(personal, 1, null, List.of(1L)));
		assertThrows(IllegalArgumentException.class, () -> asignacionService.asignarContenedores(personal, 1, hoy.plusDays(11), List.of(1L)));
		assertThrows(RuntimeException.class, () -> asignacionService.asignarContenedores(personal, 9, hoy, List.of(1L)));
		assertThrows(RuntimeException.class, () -> asignacionService.asignarContenedores(personal, 1, hoy, List.of(99L)));
		// Container 4 has never received an update from its sensor
		assertThrows(RuntimeException.class, () -> asignacionService.asignarContenedores(personal, 1, hoy, List.of(4L)));
	}
}
