package es.deusto.sd.ecoembes.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import es.deusto.sd.ecoembes.entity.PersonalEcoembes;

class AuthServiceTest {

	private AuthService authService;

	@BeforeEach
	void setUp() {
		authService = new AuthService();
		authService.addPersonal(new PersonalEcoembes("Ana", "ana@ecoembes.com", "secret"));
	}

	@Test
	void loginReturnsTokenForValidCredentials() {
		Optional<String> token = authService.login("ana@ecoembes.com", "secret");

		assertTrue(token.isPresent());
		assertEquals("Ana", authService.getPersonalByToken(token.get()).getNombre());
	}

	@Test
	void loginRejectsInvalidCredentials() {
		assertFalse(authService.login("ana@ecoembes.com", "wrong").isPresent());
		assertFalse(authService.login("nobody@ecoembes.com", "secret").isPresent());
		assertFalse(authService.login(null, null).isPresent());
	}

	@Test
	void logoutRemovesTheToken() {
		String token = authService.login("ana@ecoembes.com", "secret").get();

		assertTrue(authService.logout(token).isPresent());
		assertEquals(null, authService.getPersonalByToken(token));
		assertFalse(authService.logout(token).isPresent());
	}

	@Test
	void eachLoginGeneratesADifferentToken() {
		String token1 = authService.login("ana@ecoembes.com", "secret").get();
		String token2 = authService.login("ana@ecoembes.com", "secret").get();

		assertNotNull(token1);
		assertFalse(token1.equals(token2));
	}
}
