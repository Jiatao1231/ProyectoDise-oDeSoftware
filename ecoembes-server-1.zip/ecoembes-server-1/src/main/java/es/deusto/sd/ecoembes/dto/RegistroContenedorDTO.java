package es.deusto.sd.ecoembes.dto;

import java.time.LocalDate;

public class RegistroContenedorDTO {
	private long contenedorId;
	private String ubicacion;
	private String codigoPostal;
	private LocalDate fecha;
	private int numEnvases;
	private String nivelLlenado;

	// Constructor without parameters
	public RegistroContenedorDTO() {
	}

	// Constructor with parameters
	public RegistroContenedorDTO(long contenedorId, String ubicacion, String codigoPostal, LocalDate fecha, int numEnvases, String nivelLlenado) {
		this.contenedorId = contenedorId;
		this.ubicacion = ubicacion;
		this.codigoPostal = codigoPostal;
		this.fecha = fecha;
		this.numEnvases = numEnvases;
		this.nivelLlenado = nivelLlenado;
	}

	// Getters and setters
	public long getContenedorId() {
		return contenedorId;
	}

	public void setContenedorId(long contenedorId) {
		this.contenedorId = contenedorId;
	}

	public String getUbicacion() {
		return ubicacion;
	}

	public void setUbicacion(String ubicacion) {
		this.ubicacion = ubicacion;
	}

	public String getCodigoPostal() {
		return codigoPostal;
	}

	public void setCodigoPostal(String codigoPostal) {
		this.codigoPostal = codigoPostal;
	}

	public LocalDate getFecha() {
		return fecha;
	}

	public void setFecha(LocalDate fecha) {
		this.fecha = fecha;
	}

	public int getNumEnvases() {
		return numEnvases;
	}

	public void setNumEnvases(int numEnvases) {
		this.numEnvases = numEnvases;
	}

	public String getNivelLlenado() {
		return nivelLlenado;
	}

	public void setNivelLlenado(String nivelLlenado) {
		this.nivelLlenado = nivelLlenado;
	}
}
