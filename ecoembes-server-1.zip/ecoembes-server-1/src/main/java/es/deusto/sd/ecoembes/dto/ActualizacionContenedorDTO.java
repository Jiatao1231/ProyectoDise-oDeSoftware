package es.deusto.sd.ecoembes.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import java.time.LocalDate;

public class ActualizacionContenedorDTO {
	@Schema(description = "Date of the update (yyyy-MM-dd). If omitted, today is used", example = "2026-11-07")
	private LocalDate fecha;
	private int numEnvases;
	@Schema(description = "Fill level", allowableValues = {"VERDE", "NARANJA", "ROJO"}, example = "NARANJA")
	private String nivelLlenado;

	// Constructor without parameters
	public ActualizacionContenedorDTO() {
	}

	// Constructor with parameters
	public ActualizacionContenedorDTO(LocalDate fecha, int numEnvases, String nivelLlenado) {
		this.fecha = fecha;
		this.numEnvases = numEnvases;
		this.nivelLlenado = nivelLlenado;
	}

	// Getters and setters
	public LocalDate getFecha() {
		return fecha;
	}

	public void setFecha(LocalDate fecha) {
		this.fecha = fecha;
	}

	public int getNumEnvases() {
		return numEnvases;
	}

	public void setNumEnvases(int numEnvases) {
		this.numEnvases = numEnvases;
	}

	public String getNivelLlenado() {
		return nivelLlenado;
	}

	public void setNivelLlenado(String nivelLlenado) {
		this.nivelLlenado = nivelLlenado;
	}
}
