package es.deusto.sd.ecoembes.entity;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.apache.commons.codec.digest.DigestUtils;

public class PersonalEcoembes {

	private String nombre;
	private String password;
	private String email;
	private List<Asignacion> asignaciones = new ArrayList<>();

	// Constructor without parameters
	public PersonalEcoembes() { }

	// Constructor with parameters
	public PersonalEcoembes(String nombre, String email, String password) {
		this.nombre = nombre;
		this.email = email;
		// Passwords are never stored in plain text: they are hashed with SHA-1
		this.password = DigestUtils.sha1Hex(password);
	}

	// Check if a password is correct by comparing the SHA-1 hash of the provided
	// password against the stored hash (the plain-text password is never kept).
	public boolean checkPassword(String password) {
		return this.password.equals(DigestUtils.sha1Hex(password));
	}

	// Getters and setters
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	// Note: there is no getPassword() on purpose. As an additional security measure
	// the stored password (a SHA-1 hash) is never exposed outside the class.

	public void setPassword(String password) {
		this.password = DigestUtils.sha1Hex(password);
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public List<Asignacion> getAsignaciones() {
		return asignaciones;
	}

	public void setAsignaciones(List<Asignacion> asignaciones) {
		this.asignaciones = asignaciones;
	}

	// hashCode and equals
	@Override
	public int hashCode() {
		return Objects.hash(email, nombre);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PersonalEcoembes other = (PersonalEcoembes) obj;
		return Objects.equals(email, other.email) &&
			   Objects.equals(nombre, other.nombre);
	}
}
