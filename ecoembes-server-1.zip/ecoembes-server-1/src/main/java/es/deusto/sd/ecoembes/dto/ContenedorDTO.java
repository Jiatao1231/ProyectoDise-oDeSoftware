package es.deusto.sd.ecoembes.dto;

import java.time.LocalDate;

public class ContenedorDTO {
	private long id;
	private String ubicacion;
	private String codigoPostal;
	private int capacidadInicial;
	private LocalDate fechaUltimaActualizacion;
	private int numEnvases;
	private String nivelLlenado;

	// Constructor without parameters
	public ContenedorDTO() {
	}

	// Constructor with parameters
	public ContenedorDTO(long id, String ubicacion, String codigoPostal, int capacidadInicial, LocalDate fechaUltimaActualizacion, int numEnvases, String nivelLlenado) {
		this.id = id;
		this.ubicacion = ubicacion;
		this.codigoPostal = codigoPostal;
		this.capacidadInicial = capacidadInicial;
		this.fechaUltimaActualizacion = fechaUltimaActualizacion;
		this.numEnvases = numEnvases;
		this.nivelLlenado = nivelLlenado;
	}

	// Getters and setters
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getUbicacion() {
		return ubicacion;
	}

	public void setUbicacion(String ubicacion) {
		this.ubicacion = ubicacion;
	}

	public String getCodigoPostal() {
		return codigoPostal;
	}

	public void setCodigoPostal(String codigoPostal) {
		this.codigoPostal = codigoPostal;
	}

	public int getCapacidadInicial() {
		return capacidadInicial;
	}

	public void setCapacidadInicial(int capacidadInicial) {
		this.capacidadInicial = capacidadInicial;
	}

	public LocalDate getFechaUltimaActualizacion() {
		return fechaUltimaActualizacion;
	}

	public void setFechaUltimaActualizacion(LocalDate fechaUltimaActualizacion) {
		this.fechaUltimaActualizacion = fechaUltimaActualizacion;
	}

	public int getNumEnvases() {
		return numEnvases;
	}

	public void setNumEnvases(int numEnvases) {
		this.numEnvases = numEnvases;
	}

	public String getNivelLlenado() {
		return nivelLlenado;
	}

	public void setNivelLlenado(String nivelLlenado) {
		this.nivelLlenado = nivelLlenado;
	}
}
