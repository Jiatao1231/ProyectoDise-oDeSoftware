package es.deusto.sd.ecoembes.entity;

import java.time.LocalDate;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.CopyOnWriteArrayList;

public class Contenedor {
	private long id;
	private String ubicacion;
	private String codigoPostal;
	private int capacidadInicial;
	// Thread-safe list: it is shared across the threads serving the HTTP requests
	private List<RegistroContenedor> registros = new CopyOnWriteArrayList<>();

	// Constructor without parameters
	public Contenedor() { }

	// Constructor with parameters
	public Contenedor(long id, String ubicacion, String codigoPostal, int capacidadInicial) {
		this.id = id;
		this.ubicacion = ubicacion;
		this.codigoPostal = codigoPostal;
		this.capacidadInicial = capacidadInicial;
	}

	// Adds the daily update of the sensor. Only one update per day is kept:
	// if there was already one for that date it is replaced.
	public synchronized void addRegistro(RegistroContenedor registro) {
		registros.removeIf(r -> r.getFecha().equals(registro.getFecha()));
		registros.add(registro);
	}

	// Get the update of a specific date
	public Optional<RegistroContenedor> getRegistro(LocalDate fecha) {
		return registros.stream().filter(r -> r.getFecha().equals(fecha)).findFirst();
	}

	// Get the most recent update
	public Optional<RegistroContenedor> getUltimoRegistro() {
		return registros.stream().max((r1, r2) -> r1.getFecha().compareTo(r2.getFecha()));
	}

	// Getters and setters
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getUbicacion() {
		return ubicacion;
	}

	public void setUbicacion(String ubicacion) {
		this.ubicacion = ubicacion;
	}

	public String getCodigoPostal() {
		return codigoPostal;
	}

	public void setCodigoPostal(String codigoPostal) {
		this.codigoPostal = codigoPostal;
	}

	public int getCapacidadInicial() {
		return capacidadInicial;
	}

	public void setCapacidadInicial(int capacidadInicial) {
		this.capacidadInicial = capacidadInicial;
	}

	public List<RegistroContenedor> getRegistros() {
		return registros;
	}

	public void setRegistros(List<RegistroContenedor> registros) {
		this.registros = registros;
	}

	// hashCode and equals
	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Contenedor other = (Contenedor) obj;
		return id == other.id;
	}
}
