package es.deusto.sd.ecoembes.entity;

import java.time.LocalDate;
import java.util.Objects;

// Daily update sent by the sensor of a container
public class RegistroContenedor {
	private LocalDate fecha;
	private int numEnvases;
	private EstadoContenedor nivelLlenado;
	private Contenedor contenedor;

	// Constructor without parameters
	public RegistroContenedor() { }

	// Constructor with parameters
	public RegistroContenedor(LocalDate fecha, int numEnvases, EstadoContenedor nivelLlenado, Contenedor contenedor) {
		this.fecha = fecha;
		this.numEnvases = numEnvases;
		this.nivelLlenado = nivelLlenado;
		this.contenedor = contenedor;
	}

	// Getters and setters
	public LocalDate getFecha() {
		return fecha;
	}

	public void setFecha(LocalDate fecha) {
		this.fecha = fecha;
	}

	public int getNumEnvases() {
		return numEnvases;
	}

	public void setNumEnvases(int numEnvases) {
		this.numEnvases = numEnvases;
	}

	public EstadoContenedor getNivelLlenado() {
		return nivelLlenado;
	}

	public void setNivelLlenado(EstadoContenedor nivelLlenado) {
		this.nivelLlenado = nivelLlenado;
	}

	public Contenedor getContenedor() {
		return contenedor;
	}

	public void setContenedor(Contenedor contenedor) {
		this.contenedor = contenedor;
	}

	// hashCode and equals
	@Override
	public int hashCode() {
		return Objects.hash(contenedor, fecha);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RegistroContenedor other = (RegistroContenedor) obj;
		return Objects.equals(contenedor, other.contenedor) &&
			   Objects.equals(fecha, other.fecha);
	}
}
