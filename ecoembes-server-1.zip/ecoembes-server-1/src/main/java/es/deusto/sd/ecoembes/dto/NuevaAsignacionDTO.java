package es.deusto.sd.ecoembes.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import java.time.LocalDate;
import java.util.List;

public class NuevaAsignacionDTO {
	private long plantaId;
	@Schema(description = "Date of the assignment (yyyy-MM-dd), from today up to 10 days in advance", example = "2026-11-08")
	private LocalDate fecha;
	private List<Long> contenedores;

	// Constructor without parameters
	public NuevaAsignacionDTO() {
	}

	// Constructor with parameters
	public NuevaAsignacionDTO(long plantaId, LocalDate fecha, List<Long> contenedores) {
		this.plantaId = plantaId;
		this.fecha = fecha;
		this.contenedores = contenedores;
	}

	// Getters and setters
	public long getPlantaId() {
		return plantaId;
	}

	public void setPlantaId(long plantaId) {
		this.plantaId = plantaId;
	}

	public LocalDate getFecha() {
		return fecha;
	}

	public void setFecha(LocalDate fecha) {
		this.fecha = fecha;
	}

	public List<Long> getContenedores() {
		return contenedores;
	}

	public void setContenedores(List<Long> contenedores) {
		this.contenedores = contenedores;
	}
}
