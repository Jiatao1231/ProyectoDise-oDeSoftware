package es.deusto.sd.ecoembes.dto;

public class NuevoContenedorDTO {
	private long id;
	private String ubicacion;
	private String codigoPostal;
	private int capacidadInicial;

	// Constructor without parameters
	public NuevoContenedorDTO() {
	}

	// Constructor with parameters
	public NuevoContenedorDTO(long id, String ubicacion, String codigoPostal, int capacidadInicial) {
		this.id = id;
		this.ubicacion = ubicacion;
		this.codigoPostal = codigoPostal;
		this.capacidadInicial = capacidadInicial;
	}

	// Getters and setters
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getUbicacion() {
		return ubicacion;
	}

	public void setUbicacion(String ubicacion) {
		this.ubicacion = ubicacion;
	}

	public String getCodigoPostal() {
		return codigoPostal;
	}

	public void setCodigoPostal(String codigoPostal) {
		this.codigoPostal = codigoPostal;
	}

	public int getCapacidadInicial() {
		return capacidadInicial;
	}

	public void setCapacidadInicial(int capacidadInicial) {
		this.capacidadInicial = capacidadInicial;
	}
}
