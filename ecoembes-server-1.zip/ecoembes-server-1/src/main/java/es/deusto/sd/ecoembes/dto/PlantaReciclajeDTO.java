package es.deusto.sd.ecoembes.dto;

public class PlantaReciclajeDTO {
	private long id;
	private String nombre;
	private double capacidadDiaria;

	// Constructor without parameters
	public PlantaReciclajeDTO() {
	}

	// Constructor with parameters
	public PlantaReciclajeDTO(long id, String nombre, double capacidadDiaria) {
		this.id = id;
		this.nombre = nombre;
		this.capacidadDiaria = capacidadDiaria;
	}

	// Getters and setters
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public double getCapacidadDiaria() {
		return capacidadDiaria;
	}

	public void setCapacidadDiaria(double capacidadDiaria) {
		this.capacidadDiaria = capacidadDiaria;
	}
}
