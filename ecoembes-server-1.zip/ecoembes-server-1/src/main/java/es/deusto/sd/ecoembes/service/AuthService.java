package es.deusto.sd.ecoembes.service;

import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Service;

import es.deusto.sd.ecoembes.entity.PersonalEcoembes;

@Service
public class AuthService {

	// Simulating a staff repository (thread-safe: shared across request threads)
	private final Map<String, PersonalEcoembes> personalRepository = new ConcurrentHashMap<>();

	// Storage to keep the session of the staff that is logged in (server state)
	private final Map<String, PersonalEcoembes> tokenStore = new ConcurrentHashMap<>();

	// Login method that checks if the person exists and validates the password
	public Optional<String> login(String email, String password) {
		if (email == null || password == null) {
			return Optional.empty();
		}

		PersonalEcoembes personal = personalRepository.get(email);

		if (personal != null && personal.checkPassword(password)) {
			String token = generateToken();  // Generate a unique token for the session
			tokenStore.put(token, personal); // Store the token and associate it with the person

			return Optional.of(token);
		} else {
			return Optional.empty();
		}
	}

	// Logout method to remove the token from the session store
	public Optional<Boolean> logout(String token) {
		if (token != null && tokenStore.containsKey(token)) {
			tokenStore.remove(token);

			return Optional.of(true);
		} else {
			return Optional.empty();
		}
	}

	// Method to add a new person of the staff to the repository
	public void addPersonal(PersonalEcoembes personal) {
		if (personal != null) {
			personalRepository.putIfAbsent(personal.getEmail(), personal);
		}
	}

	// Method to get the person based on the token
	public PersonalEcoembes getPersonalByToken(String token) {
		if (token == null) {
			return null;
		}

		return tokenStore.get(token);
	}

	// Method to get the person based on the email
	public PersonalEcoembes getPersonalByEmail(String email) {
		return personalRepository.get(email);
	}

	// Generates a unique, non-guessable session token.
	private static String generateToken() {
		return UUID.randomUUID().toString();
	}
}
