package es.deusto.sd.ecoembes.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Service;

import es.deusto.sd.ecoembes.entity.PlantaReciclaje;

@Service
public class PlantaService {

	// The capacity of the plants is only available 10 days in advance
	public static final int DIAS_ANTELACION = 10;

	// Simulating the recycling plants repository.
	// In this first prototype the information of the plants (PlasSB Ltd. and ContSocket Ltd.)
	// is simulated here; the communication with the external services comes in the next prototype.
	private final Map<Long, PlantaReciclaje> plantaRepository = new ConcurrentHashMap<>();

	// Get all the recycling plants
	public List<PlantaReciclaje> getPlantas() {
		return plantaRepository.values().stream()
				.sorted((p1, p2) -> Long.compare(p1.getId(), p2.getId()))
				.toList();
	}

	// Get a recycling plant by id
	public PlantaReciclaje getPlantaById(long id) {
		return plantaRepository.get(id);
	}

	// Get the capacity (in tons) available on a given date for a specific plant
	public double getCapacidadDisponible(long plantaId, LocalDate fecha) {
		validarFechaConsulta(fecha);

		PlantaReciclaje planta = plantaRepository.get(plantaId);

		if (planta == null) {
			throw new RuntimeException("Plant not found");
		}

		return planta.getCapacidadDisponible(fecha);
	}

	// A date is valid when it is not further than 10 days in advance
	public static void validarFechaConsulta(LocalDate fecha) {
		if (fecha == null || fecha.isAfter(LocalDate.now().plusDays(DIAS_ANTELACION))) {
			throw new IllegalArgumentException("Invalid date");
		}
	}

	// Method to add a new recycling plant
	public void addPlanta(PlantaReciclaje planta) {
		if (planta != null) {
			plantaRepository.putIfAbsent(planta.getId(), planta);
		}
	}
}
