package es.deusto.sd.ecoembes.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Service;

import es.deusto.sd.ecoembes.entity.Contenedor;
import es.deusto.sd.ecoembes.entity.EstadoContenedor;
import es.deusto.sd.ecoembes.entity.RegistroContenedor;

@Service
public class ContenedorService {

	// Simulating the container repository.
	// ConcurrentHashMap is used because the repository is shared across the
	// threads that Spring uses to serve concurrent HTTP requests.
	private final Map<Long, Contenedor> contenedorRepository = new ConcurrentHashMap<>();

	// Get all the containers
	public List<Contenedor> getContenedores() {
		return contenedorRepository.values().stream()
				.sorted((c1, c2) -> Long.compare(c1.getId(), c2.getId()))
				.toList();
	}

	// Get container by id
	public Contenedor getContenedorById(long id) {
		return contenedorRepository.get(id);
	}

	// Create a new container
	public Contenedor crearContenedor(long id, String ubicacion, String codigoPostal, int capacidadInicial) {
		if (ubicacion == null || ubicacion.isBlank() || codigoPostal == null || codigoPostal.isBlank()
				|| capacidadInicial <= 0) {
			throw new IllegalArgumentException("Invalid container data");
		}

		Contenedor contenedor = new Contenedor(id, ubicacion, codigoPostal, capacidadInicial);

		if (contenedorRepository.putIfAbsent(id, contenedor) != null) {
			throw new RuntimeException("Container already exists");
		}

		return contenedor;
	}

	// Register the daily update sent by the sensor of a container
	public void actualizarContenedor(long id, LocalDate fecha, int numEnvases, EstadoContenedor nivelLlenado) {
		if (numEnvases < 0 || nivelLlenado == null) {
			throw new IllegalArgumentException("Invalid container data");
		}

		// If there is no date, the update is registered for today
		LocalDate fechaRegistro = (fecha != null) ? fecha : LocalDate.now();

		if (fechaRegistro.isAfter(LocalDate.now())) {
			throw new IllegalArgumentException("Invalid container data");
		}

		Contenedor contenedor = contenedorRepository.get(id);

		if (contenedor == null) {
			throw new RuntimeException("Container not found");
		}

		contenedor.addRegistro(new RegistroContenedor(fechaRegistro, numEnvases, nivelLlenado, contenedor));
	}

	// Get the updates of a container between two dates (both included)
	public List<RegistroContenedor> getRegistrosByFechas(long id, LocalDate fechaInicio, LocalDate fechaFin) {
		if (fechaInicio == null || fechaFin == null || fechaInicio.isAfter(fechaFin)) {
			throw new IllegalArgumentException("Invalid date range");
		}

		Contenedor contenedor = contenedorRepository.get(id);

		if (contenedor == null) {
			throw new RuntimeException("Container not found");
		}

		return contenedor.getRegistros().stream()
				.filter(r -> !r.getFecha().isBefore(fechaInicio) && !r.getFecha().isAfter(fechaFin))
				.sorted((r1, r2) -> r1.getFecha().compareTo(r2.getFecha()))
				.toList();
	}

	// Get the state of the containers of a zone (postal code) on a given date
	public List<RegistroContenedor> getRegistrosByZona(String codigoPostal, LocalDate fecha) {
		if (codigoPostal == null || codigoPostal.isBlank() || fecha == null) {
			throw new IllegalArgumentException("Invalid date range");
		}

		return getContenedores().stream()
				.filter(c -> codigoPostal.equals(c.getCodigoPostal()))
				.map(c -> c.getRegistro(fecha))
				.filter(r -> r.isPresent())
				.map(r -> r.get())
				.toList();
	}
}
