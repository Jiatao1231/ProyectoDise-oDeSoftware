package es.deusto.sd.ecoembes.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class AsignacionDTO {
	private long id;
	private LocalDate fecha;
	private long plantaId;
	private String plantaNombre;
	private int numContenedores;
	private int totalEnvases;
	private double toneladas;
	private String responsable;
	private LocalDateTime fechaRegistro;

	// Constructor without parameters
	public AsignacionDTO() {
	}

	// Constructor with parameters
	public AsignacionDTO(long id, LocalDate fecha, long plantaId, String plantaNombre, int numContenedores, int totalEnvases, double toneladas, String responsable, LocalDateTime fechaRegistro) {
		this.id = id;
		this.fecha = fecha;
		this.plantaId = plantaId;
		this.plantaNombre = plantaNombre;
		this.numContenedores = numContenedores;
		this.totalEnvases = totalEnvases;
		this.toneladas = toneladas;
		this.responsable = responsable;
		this.fechaRegistro = fechaRegistro;
	}

	// Getters and setters
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public LocalDate getFecha() {
		return fecha;
	}

	public void setFecha(LocalDate fecha) {
		this.fecha = fecha;
	}

	public long getPlantaId() {
		return plantaId;
	}

	public void setPlantaId(long plantaId) {
		this.plantaId = plantaId;
	}

	public String getPlantaNombre() {
		return plantaNombre;
	}

	public void setPlantaNombre(String plantaNombre) {
		this.plantaNombre = plantaNombre;
	}

	public int getNumContenedores() {
		return numContenedores;
	}

	public void setNumContenedores(int numContenedores) {
		this.numContenedores = numContenedores;
	}

	public int getTotalEnvases() {
		return totalEnvases;
	}

	public void setTotalEnvases(int totalEnvases) {
		this.totalEnvases = totalEnvases;
	}

	public double getToneladas() {
		return toneladas;
	}

	public void setToneladas(double toneladas) {
		this.toneladas = toneladas;
	}

	public String getResponsable() {
		return responsable;
	}

	public void setResponsable(String responsable) {
		this.responsable = responsable;
	}

	public LocalDateTime getFechaRegistro() {
		return fechaRegistro;
	}

	public void setFechaRegistro(LocalDateTime fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}
}
