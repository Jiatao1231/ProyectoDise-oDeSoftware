package es.deusto.sd.ecoembes;

import java.time.LocalDate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import es.deusto.sd.ecoembes.entity.Contenedor;
import es.deusto.sd.ecoembes.entity.EstadoContenedor;
import es.deusto.sd.ecoembes.entity.PersonalEcoembes;
import es.deusto.sd.ecoembes.entity.PlantaReciclaje;
import es.deusto.sd.ecoembes.service.AuthService;
import es.deusto.sd.ecoembes.service.ContenedorService;
import es.deusto.sd.ecoembes.service.PlantaService;

@Configuration
public class DataInitializer {

	private static final Logger logger = LoggerFactory.getLogger(DataInitializer.class);

	@Bean
	CommandLineRunner initData(AuthService authService, ContenedorService contenedorService,
			PlantaService plantaService) {
		return args -> {
			// Create some staff profiles.
			PersonalEcoembes ana = new PersonalEcoembes("Ana Garcia", "ana@ecoembes.com", "Ana1234!");
			PersonalEcoembes mikel = new PersonalEcoembes("Mikel Etxeberria", "mikel@ecoembes.com", "Mikel1234!");
			PersonalEcoembes laura = new PersonalEcoembes("Laura Perez", "laura@ecoembes.com", "Laura1234!");

			authService.addPersonal(ana);
			authService.addPersonal(mikel);
			authService.addPersonal(laura);

			logger.info("Staff saved!");

			// Create the recycling plants (capacity in tons per day)
			plantaService.addPlanta(new PlantaReciclaje(1, "PlasSB Ltd.", 0.60));
			plantaService.addPlanta(new PlantaReciclaje(2, "ContSocket Ltd.", 0.40));

			logger.info("Recycling plants saved!");

			// Create some containers
			String[] ubicaciones = {
				"Gran Via 25, Bilbao", "Calle Autonomia 10, Bilbao", "Alameda Recalde 30, Bilbao",
				"Calle Ercilla 15, Bilbao", "Calle Ledesma 8, Bilbao", "Avenida Lehendakari Aguirre 20, Bilbao",
				"Calle Iparraguirre 40, Bilbao", "Calle Rodriguez Arias 12, Bilbao"
			};
			String[] codigosPostales = { "48001", "48001", "48009", "48009", "48011", "48010", "48011", "48010" };
			int[] numEnvases = { 300, 1100, 1750, 600, 1900, 900, 1500, 200 };

			// Each container has the updates of the sensor of the last 3 days
			LocalDate hoy = LocalDate.now();
			int capacidadInicial = 2000;

			for (int i = 0; i < ubicaciones.length; i++) {
				Contenedor contenedor = contenedorService.crearContenedor(i + 1, ubicaciones[i], codigosPostales[i],
						capacidadInicial);

				for (int dias = 2; dias >= 0; dias--) {
					int envases = Math.max(0, numEnvases[i] - dias * 200);
					contenedorService.actualizarContenedor(contenedor.getId(), hoy.minusDays(dias), envases,
							calcularEstado(envases, capacidadInicial));
				}
			}

			logger.info("Containers saved!");
		};
	}

	// Fill level: GREEN below 50%, ORANGE below 80%, RED otherwise
	private EstadoContenedor calcularEstado(int numEnvases, int capacidad) {
		double ocupacion = (double) numEnvases / capacidad;

		if (ocupacion < 0.5) {
			return EstadoContenedor.VERDE;
		} else if (ocupacion < 0.8) {
			return EstadoContenedor.NARANJA;
		} else {
			return EstadoContenedor.ROJO;
		}
	}
}
