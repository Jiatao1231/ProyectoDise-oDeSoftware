package es.deusto.sd.ecoembes.entity;

// Fill levels reported by the sensor of a container
public enum EstadoContenedor {
	VERDE,   // There is free space available
	NARANJA, // Limited space
	ROJO     // Container is full
}
