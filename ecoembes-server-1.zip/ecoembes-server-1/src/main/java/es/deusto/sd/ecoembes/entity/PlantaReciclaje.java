package es.deusto.sd.ecoembes.entity;

import java.time.LocalDate;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.CopyOnWriteArrayList;

public class PlantaReciclaje {
	private long id;
	private String nombre;
	// Recycling capacity of the plant for each day (in tons)
	private double capacidadDiaria;
	// Thread-safe list: it is shared across the threads serving the HTTP requests
	private List<Asignacion> asignaciones = new CopyOnWriteArrayList<>();

	// Constructor without parameters
	public PlantaReciclaje() { }

	// Constructor with parameters
	public PlantaReciclaje(long id, String nombre, double capacidadDiaria) {
		this.id = id;
		this.nombre = nombre;
		this.capacidadDiaria = capacidadDiaria;
	}

	// Get the capacity (in tons) still available on a given date:
	// the daily capacity minus what has already been assigned to the plant that day.
	public double getCapacidadDisponible(LocalDate fecha) {
		double asignado = asignaciones.stream()
				.filter(a -> a.getFecha().equals(fecha))
				.mapToDouble(Asignacion::getToneladas)
				.sum();

		// Rounded to 6 decimals to avoid floating point noise (e.g. 0.24250000000000002)
		return Math.round(Math.max(0.0, capacidadDiaria - asignado) * 1_000_000d) / 1_000_000d;
	}

	// Getters and setters
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public double getCapacidadDiaria() {
		return capacidadDiaria;
	}

	public void setCapacidadDiaria(double capacidadDiaria) {
		this.capacidadDiaria = capacidadDiaria;
	}

	public List<Asignacion> getAsignaciones() {
		return asignaciones;
	}

	public void setAsignaciones(List<Asignacion> asignaciones) {
		this.asignaciones = asignaciones;
	}

	// hashCode and equals
	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PlantaReciclaje other = (PlantaReciclaje) obj;
		return id == other.id;
	}
}
