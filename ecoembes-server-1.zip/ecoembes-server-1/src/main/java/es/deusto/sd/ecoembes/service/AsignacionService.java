package es.deusto.sd.ecoembes.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import es.deusto.sd.ecoembes.entity.Asignacion;
import es.deusto.sd.ecoembes.entity.Contenedor;
import es.deusto.sd.ecoembes.entity.PersonalEcoembes;
import es.deusto.sd.ecoembes.entity.PlantaReciclaje;
import es.deusto.sd.ecoembes.entity.RegistroContenedor;

@Service
public class AsignacionService {

	private static final Logger logger = LoggerFactory.getLogger(AsignacionService.class);

	private final ContenedorService contenedorService;
	private final PlantaService plantaService;

	// Simulating the assignments repository
	private final Map<Long, Asignacion> asignacionRepository = new ConcurrentHashMap<>();
	private final AtomicLong nextId = new AtomicLong(1);

	public AsignacionService(ContenedorService contenedorService, PlantaService plantaService) {
		this.contenedorService = contenedorService;
		this.plantaService = plantaService;
	}

	// Get all the assignments (audit)
	public List<Asignacion> getAsignaciones() {
		return asignacionRepository.values().stream()
				.sorted((a1, a2) -> Long.compare(a1.getId(), a2.getId()))
				.toList();
	}

	// Assign a set of containers to a recycling plant for a given date.
	// The method is synchronized: checking the available capacity of the plant and
	// registering the assignment must be atomic, otherwise two concurrent assignments
	// could both pass the check and exceed the capacity of the plant.
	public synchronized Asignacion asignarContenedores(PersonalEcoembes personal, long plantaId, LocalDate fecha,
			List<Long> idsContenedores) {
		if (idsContenedores == null || idsContenedores.isEmpty() || fecha == null || fecha.isBefore(LocalDate.now())) {
			throw new IllegalArgumentException("Invalid assignment data");
		}

		PlantaService.validarFechaConsulta(fecha);

		PlantaReciclaje planta = plantaService.getPlantaById(plantaId);

		if (planta == null) {
			throw new RuntimeException("Plant not found");
		}

		// Retrieve the containers (repeated ids are ignored)
		Set<Long> ids = new LinkedHashSet<>(idsContenedores);
		List<Contenedor> contenedores = new ArrayList<>();
		int totalEnvases = 0;

		for (Long id : ids) {
			Contenedor contenedor = (id != null) ? contenedorService.getContenedorById(id) : null;

			if (contenedor == null) {
				throw new RuntimeException("Container not found");
			}

			RegistroContenedor ultimo = contenedor.getUltimoRegistro().orElse(null);

			if (ultimo == null) {
				throw new RuntimeException("Container without fill information");
			}

			if (estaAsignado(contenedor, fecha)) {
				throw new RuntimeException("Container already assigned");
			}

			contenedores.add(contenedor);
			totalEnvases += ultimo.getNumEnvases();
		}

		// Check that the plant has enough capacity for the packagings of the containers
		double toneladas = totalEnvases * Asignacion.PESO_MEDIO_ENVASE_TONELADAS;

		if (toneladas > planta.getCapacidadDisponible(fecha)) {
			throw new RuntimeException("Insufficient plant capacity");
		}

		// Register the assignment together with the person who made it (audit)
		Asignacion asignacion = new Asignacion(nextId.getAndIncrement(), fecha, totalEnvases, planta, personal,
				contenedores);
		asignacionRepository.put(asignacion.getId(), asignacion);

		// Simulated notification to the recycling plant
		logger.info("Notification to plant '{}': {} containers, {} estimated packagings (assigned by {})",
				planta.getNombre(), contenedores.size(), totalEnvases, personal.getEmail());

		return asignacion;
	}

	// A container can only be assigned once per date
	private boolean estaAsignado(Contenedor contenedor, LocalDate fecha) {
		return asignacionRepository.values().stream()
				.anyMatch(a -> a.getFecha().equals(fecha) && a.getContenedores().contains(contenedor));
	}
}
